import { forwardRef, Module } from '@nestjs/common';
import { AuthModule } from '@thallesp/nestjs-better-auth';
import { auth } from './auth';
import { BetterAuthService } from './better-auth.service';
import { BetterAuthController } from './better-auth.controller';
import { UsersModule } from 'src/users/users.module';
import { ActionsHook } from './hooks/actions.hook';
import { HttpModule } from '@nestjs/axios';

@Module({
    imports: [
        AuthModule.forRoot({ 
            auth,
            disableTrustedOriginsCors: false,
            disableBodyParser: false,
        }),
        forwardRef(() => UsersModule),
        HttpModule.registerAsync({
            useFactory: () => ({
                timeout: 5000,
                maxRedirects: 5,
            }),
        }),
    ],
    controllers: [BetterAuthController],
    providers: [BetterAuthService, ActionsHook],
    exports: [BetterAuthService],
})
export class BetterAuthModule {}
