import { Injectable } from '@nestjs/common';
import { AuthService } from '@thallesp/nestjs-better-auth';
import { auth } from './auth';

@Injectable()
export class BetterAuthService extends AuthService<typeof auth>{}
