import { Injectable, Session } from "@nestjs/common";
import {
  AfterHook,
  BeforeHook,
  Hook,
  type AuthHookContext,
} from "@thallesp/nestjs-better-auth";
import { BetterAuthService } from "../better-auth.service";
import { UsersService } from "src/users/users.service";
import { User } from "src/users/users.entity";

@Hook()
@Injectable()
export class ActionsHook {
  constructor(private readonly usersService: UsersService) {}

  @BeforeHook("/sign-up/email")
  async signup(ctx: AuthHookContext) {
    const email = ctx.body.email;
    const user = await this.usersService.findByEmail(email);
    if (user) {
      throw new Error("Email already exists");
    }else{
        this.usersService.create({
            name: ctx.body.name,
            email: ctx.body.email,
            phoneNumber: ctx.body.phoneNumber,
            image: ctx.body.image,
            createdAt: new Date(),
            updatedAt: new Date(),
        } as User);
    }    
  }

  @BeforeHook("/sign-in/email")
  async signin(ctx: AuthHookContext) {
    const email = ctx.body.email;
    const user = await this.usersService.findByEmail(email);    
    if (!user) {
      throw new Error("User not found");
    }
  }

  @AfterHook("/sign-in/email")
  async afterSignin(ctx: AuthHookContext) {
    console.log("After Signin");
    const authToken = ctx.context;
    console.log(authToken);
  }

  @BeforeHook("/reset-password/email")
  async resetPassword(ctx: AuthHookContext) {
    const email = ctx.body.email;
    const user = await this.usersService.findByEmail(email);
    if (!user) {
      throw new Error("User not found");
    }
  }

  @BeforeHook("/change-password")
  async updatePassword(ctx: AuthHookContext) {
    const email = ctx.context.session?.user.email;
    const user = await this.usersService.findByEmail(email || '');
    if (!user) {
      throw new Error("User not found");
    }
  }

  @AfterHook("/change-email")
  async updateEmail(ctx: AuthHookContext) {
    const oldEmail = ctx.context.session?.user.email;
    const email = ctx.body.newEmail;
    const user = await this.usersService.findByEmail(oldEmail || '');
    if (!user) {
      throw new Error("User not found");
    }else{
        await this.usersService.update(user.id || 0, {
            name: user.name,
            email: email,
            phoneNumber: user.phoneNumber,
            image: user.image,
            createdAt: user.createdAt,
            updatedAt: new Date(),
        }as User);
    }
  }

  @BeforeHook("/update-user")
  async updateProfile(ctx: AuthHookContext) {
    const email = ctx.context.session?.user.email;
    const user = await this.usersService.findByEmail(email || '');
    if (!user) {
      throw new Error("User not found");
    }else{
        await this.usersService.update(user.id || 0, {
            name: ctx.body.name,
            email: user.email,
            phoneNumber: ctx.body.phoneNumber,
            image: ctx.body.image,
            createdAt: user.createdAt,
            updatedAt: new Date(),
        }as User);
    }
  }

  @AfterHook("/delete-user")
  async deleteProfile(ctx: AuthHookContext) {
    const email = ctx.context.session?.user.email;
    const user = await this.usersService.findByEmail(email || '');
    if (!user) {
      throw new Error("User not found");
    }else{
        await this.usersService.delete(user.id || 0);
    }
  }
}