import { betterAuth } from "better-auth";
import { admin, emailOTP, openAPI, phoneNumber } from "better-auth/plugins";
import { createPool } from "mysql2/promise";

export const auth = betterAuth({
  basePath: "/api/auth",
  database: createPool({
      host: process.env.DB_HOST || "localhost",
      port: (process.env.DB_PORT || 3306) as number,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "password",
      database: process.env.DB_NAME || "jobs_for_women",
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      multipleStatements: true,
  }),
  emailAndPassword: {
      enabled: true,
  },
  hooks: {},
  plugins: [
    admin(),
    openAPI({
        path: "/docs",
    }),
    emailOTP({ 
        async sendVerificationOTP({ email, otp, type }) { 
            if (type === "sign-in") { 
                // Send the OTP for sign in
            } else if (type === "email-verification") { 
                // Send the OTP for email verification
            } else { 
                // Send the OTP for password reset
            } 
        }, 
    }),
    phoneNumber({  
        sendOTP: ({ phoneNumber, code }, request) => { 
            // Implement sending OTP code via SMS
        } 
    })  
  ]
});