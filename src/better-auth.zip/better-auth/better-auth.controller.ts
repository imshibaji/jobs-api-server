import { Body, Controller, Delete, Get, Post, Put, Query, Request } from '@nestjs/common';
import { BetterAuthService } from './better-auth.service';
import type { Request as ExpressRequest } from 'express';
import { fromNodeHeaders } from 'better-auth/node';
import { ApiProperty } from '@nestjs/swagger';
import { ApiKeys, ChangeEmail, ChangePassword, DeleteUser, ForgotPassword, Login, RefreshToken, Register, ResetPassword, UpdateUser, Verify } from './types/auth-types';
import { AllowAnonymous, OptionalAuth } from '@thallesp/nestjs-better-auth';
import { HttpService } from '@nestjs/axios';
import { APIError } from 'better-auth';

@Controller('better-auth')
export class BetterAuthController {
    constructor(
        private readonly betterAuthService: BetterAuthService,
        private readonly httpService: HttpService,
    ) {}

    @Get('me')
    @OptionalAuth()
    async me(@Request() req: ExpressRequest) {
        return await this.betterAuthService.api.getSession({
            headers: fromNodeHeaders(req.headers),
        });
    }

    @Post('login')
    @AllowAnonymous()
    @ApiProperty({ type: Login })
    async login(@Request() req: ExpressRequest, @Body() body: Login) {
        try {
                const resp = await this.betterAuthService.instance.api.signInEmail({
                    body: {
                        email: body.email,
                        password: body.password,
                    },
                    headers: fromNodeHeaders(req.headers),
                });
                return resp;
            } catch (error) {
                if (error instanceof APIError) {
                    console.log(error.message, error.status)
                }
            }
    }

    @Post('register')
    @AllowAnonymous()
    @ApiProperty({ type: Register })
    async register(@Body() body: Register){
        return await this.betterAuthService.api.signUpEmail({
            body: {
                name: body.name,
                email: body.email,
                password: body.password,
                phoneNumber: body.phoneNumber,
                image: body.image,
            },
        });
    }

    @Post('logout')
    async logout(@Request() req: ExpressRequest){
        return await this.betterAuthService.api.signOut({
            headers: fromNodeHeaders(req.headers),
        });
    }

    @Put('refresh')
    @AllowAnonymous()
    @ApiProperty({ type: RefreshToken, required: true })
    async refresh(@Body() body: RefreshToken){
        return await this.betterAuthService.api.refreshToken({body});
    }

    @Put('verify')
    @AllowAnonymous()
    @ApiProperty({ type: Verify, required: true })
    async verify(@Query() query: Verify) {
        return await this.betterAuthService.api.verifyEmail({
            query: {
                token: query.token,
            },
        });
    }

    @Put('forgot-password')
    @AllowAnonymous()
    @ApiProperty({ type: ForgotPassword, required: true })
    async forgotPassword(@Body() body: ForgotPassword) {
        return await this.betterAuthService.api.forgetPassword({
            body: {
                email: body.email,
            },
        });
    }

    @Put('reset-password')
    @AllowAnonymous()
    @ApiProperty({ type: ResetPassword, required: true })
    async resetPassword(@Body() body: ResetPassword) {
        return await this.betterAuthService.api.resetPassword({
            body: {
                newPassword: body.newPassword,
            },
        });
    }

    @Put('change-password')
    @ApiProperty({ type: ChangePassword, required: true })
    async changePassword(@Body() body: ChangePassword) {
        return await this.betterAuthService.api.changePassword({
            body: {
                currentPassword: body.currentPassword,
                newPassword: body.newPassword,
            },
        });
    }

    @Put('change-email')
    @ApiProperty({ type: ChangeEmail, required: true })
    async changeEmail(@Body() body: ChangeEmail) {
        return await this.betterAuthService.api.changeEmail({
            body: {
                newEmail: body.newEmail,
            },
        });
    }

    @Put('update-user')
    @ApiProperty({ type: UpdateUser, required: true })
    async updateUser(@Body() body: UpdateUser) {
        return await this.betterAuthService.api.updateUser({
            body: {
                name: body.name,
                phoneNumber: body.phoneNumber,
                image: body.image,
            },
        });
    }

    @Delete('delete-user')
    @ApiProperty({ type: DeleteUser, required: true })
    deleteUser(@Body() body: DeleteUser){
        return this.betterAuthService.api.deleteUser({
            body: body,
        });
    }
}
