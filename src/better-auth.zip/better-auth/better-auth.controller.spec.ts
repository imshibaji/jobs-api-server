import { Test, TestingModule } from '@nestjs/testing';
import { BetterAuthController } from './better-auth.controller';

describe('BetterAuthController', () => {
  let controller: BetterAuthController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [BetterAuthController],
    }).compile();

    controller = module.get<BetterAuthController>(BetterAuthController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
