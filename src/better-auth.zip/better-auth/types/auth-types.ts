import { ApiProperty } from "@nestjs/swagger";

export class ApiKeys{
    @ApiProperty({ type: String, required: false })
    name?: string;
    @ApiProperty({ type: Number, required: false })
    expiresIn?: number;
    @ApiProperty({ type: String, required: false })
    userId?: unknown;
    @ApiProperty({ type: String, required: false })
    prefix?: string;
    @ApiProperty({ type: String, required: false })
    remaining?: number | null | undefined;
    @ApiProperty({ type: String, required: false })
    metadata?: any;
    @ApiProperty({ type: Number, required: false })
    refillAmount?: number;
    @ApiProperty({ type: Number, required: false })
    refillInterval?: number;
    @ApiProperty({ type: Number, required: false })
    rateLimitTimeWindow?: number;
    @ApiProperty({ type: Number, required: false })
    rateLimitMax?: number;
    @ApiProperty({ type: Boolean, required: false })
    rateLimitEnabled?: boolean;
    @ApiProperty({ type: Object, required: false })
    permissions?: Record<string, string[]>;
}

export class Login{
    @ApiProperty({ type: String, required: true })
    email: string;
    @ApiProperty({ type: String, required: true })
    password: string;
    @ApiProperty({ type: String, required: false })
    callbackURL?: string;
    @ApiProperty({ type: Boolean, required: false })
    rememberMe?: boolean;
}

export class Register{
    @ApiProperty({ type: String, required: true })
    name: string;
    @ApiProperty({ type: String, required: true })
    email: string;
    @ApiProperty({ type: String, required: true })
    password: string;
    @ApiProperty({ type: String, required: false })
    phoneNumber?: string;
    @ApiProperty({ type: String, required: false })
    image?: string;
}

export class RefreshToken{
    @ApiProperty({ type: String, required: true })
    providerId: string;
    @ApiProperty({ type: String, required: false })
    accountId: string;
    @ApiProperty({ type: String, required: true })
    userId: string;
}

export class Verify{
    @ApiProperty({ type: String, required: true })
    token: string;
}

export class ForgotPassword{
    @ApiProperty({ type: String, required: true })
    email: string;
}

export class ResetPassword{
    @ApiProperty({ type: String, required: true })
    newPassword: string;
}

export class ChangePassword{
    @ApiProperty({ type: String, required: true })
    currentPassword: string;
    @ApiProperty({ type: String, required: true })
    newPassword: string;
}

export class ChangeEmail{
    @ApiProperty({ type: String, required: true })
    newEmail: string;
}

export class ChangePhoneNumber{
    @ApiProperty({ type: String, required: true })
    newPhoneNumber: string;
}

export class UpdateUser{
    @ApiProperty({ type: String, required: false })
    name?: string;
    @ApiProperty({ type: String, required: false })
    phoneNumber?: string;
    @ApiProperty({ type: String, required: false })
    image?: string;
}
export class DeleteUser{
    @ApiProperty({ type: String, required: true })
    callbackURL?: string;
    @ApiProperty({ type: String, required: false })
    password?: string;
    @ApiProperty({ type: String, required: false })
    token?: string;
}